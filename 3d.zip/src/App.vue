<script setup lang="ts">
import aroundFont from './components/aroundFont.vue'
import hoverFont from './components/hoverFont.vue'
</script>

<template>
  <aroundFont />
  <hoverFont />
</template>

<style scoped></style>
